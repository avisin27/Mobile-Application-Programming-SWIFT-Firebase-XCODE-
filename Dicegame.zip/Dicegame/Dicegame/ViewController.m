//
//  ViewController.m
//  Dice Roll Game
//
//  Created by Avi Singhal on 20/02/2018.
// Copyright © 2018 Apple Inc. All rights reserved.
//

#import "ViewController.h"
#import "DiceView.h"
#import "InstructionsViewController.h"
#import "AboutAuthorViewController.h"

@interface ViewController ()
{
    NSInteger robotDiceValue;
    NSInteger playerDiceValue;
}
@property (strong, nonatomic) NSArray *dice;
@property BOOL areDiceRolling;
@end

@implementation ViewController

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    _amountLabel.text = [NSString stringWithFormat:@"%ld",(long)[[NSUserDefaults standardUserDefaults] integerForKey:@"amountInAccount"]];
    
    [_betSlider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    
    // Create the dice for this view
    int randomValue = (int) 1 + arc4random() % 6;
    
    _dice1View = [_dice1View initWithFrame:_dice1View.frame andValue:randomValue];
    _dice1View.tag = 0;
    
    randomValue = (int) 1 + arc4random() % 6;
    _dice2view = [_dice2view initWithFrame:_dice2view.frame andValue:randomValue];
    _dice2view.tag = 1;
    
    // Creates an array containing all of the dice
    self.dice = [[NSArray alloc] initWithObjects:_dice1View, _dice2view,nil];
    

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)rollButtonTapped:(id)sender {
    if(!self.areDiceRolling )
    {
        // Prevent dice from being rolled if they are already rolling
        self.areDiceRolling = YES;
        
        for (DiceView *die in self.dice) {
            // For each die lets find a random spot on the screen and move it there and then back
            CGPoint originalCenter = die.center;
            
            // Get a random spot on the bottom half of the screen
            int newX = 1 + arc4random() % 320;
            int newY = 200 + arc4random() % 280;
            
            // Animate each die out and once the animation is complete, animate
            // it back to its original position
            [UIView animateWithDuration:0.75
                                  delay:0
                                options:UIViewAnimationOptionBeginFromCurrentState
                             animations:^{
                                 
                                 // Spin the die 2.5x
                                 [die spinThisDieFor:0.75f];
                                 
                                 // After a 0.35 second delay call the function to change the die value
                                 [self performSelector:@selector(changeValueOf:) withObject:die afterDelay:0.35f];
                                 
                                 // Animate the die to the new randomly chosen position
                                 [die setCenter:CGPointMake(newX, newY)];
                                 
                             }
                             completion:^(BOOL completion) {
                                 [UIView animateWithDuration:0.75
                                                       delay:0
                                                     options:UIViewAnimationOptionBeginFromCurrentState
                                                  animations:^{
                                                      
                                                      // Spin the die 2.5x
                                                      [die spinThisDieFor:0.75f];
                                                      
                                                      // After a 0.35 second delay call the function to change the die value
                                                      [self performSelector:@selector(changeValueOf:) withObject:die afterDelay:0.35f];
                                                      
                                                      // Return the die to its original position
                                                      [die setCenter:originalCenter];
                                                      
                                                      // Set property to allow dice to roll again
                                                      self.areDiceRolling = NO;
                                                      
                                                      if (die.tag == 1) {
                                                          [self performSelector:@selector(checkDiceValues) withObject:nil afterDelay:1.0f];
                                                      }
                                                      
                                                      
                                                  } completion:nil];
                             }];
            
        }
        
    }
}

/*
*  Changes the value of a die and sets it to needs display
*  which will trigger it to be redrawn
*  @param die The die to change the value of
*/
- (void)changeValueOf:(DiceView *)die
{
   
    die.dieValue = 1 + arc4random() % 6;
    if (die.tag == 0) {
        robotDiceValue = die.dieValue;
    }
    else if (die.tag == 1)
    {
        playerDiceValue = die.dieValue;
    }
    [die setNeedsDisplay];
    
}

-(void)checkDiceValues
{
    if (robotDiceValue == playerDiceValue) {
      
        [self showAlertWithTitle:@"TIE" andMessage:@"Its a Tie, Roll again"];
        NSLog(@"Roll again ");
    }
    else if (robotDiceValue < playerDiceValue) {
     
        [self showAlertWithTitle:@"Congratulations" andMessage:@"You Won the Bet, Moved to Next Round"];
        NSLog(@"You Won the Bet, Moved to Next Round ");
        long int prevAmount = [_amountLabel.text integerValue];
        long int BettingAmount = [_betAmountLabel.text integerValue];
        long int totalAMount = prevAmount + BettingAmount;
        _amountLabel.text = [NSString stringWithFormat:@"%ld",totalAMount];
        [[NSUserDefaults standardUserDefaults] setInteger:totalAMount forKey:@"amountInAccount"];
        
        long int round = [_roundLabel.text integerValue];
        round ++;
        _roundLabel.text = [NSString stringWithFormat:@"%ld",round];
    }
    else
    {
        [self showAlertWithTitle:@"Sorry" andMessage:@"You Lost the Bet, Game Over"];
        NSLog(@"You lost, game over ");
        
        _roundLabel.text = @"0";
    }
}

- (IBAction)sliderValueChanged:(UISlider *)sender {

    long int sliderValue;
    sliderValue = lroundf(_betSlider.value);
    [_betSlider setValue:sliderValue animated:YES];
    
    NSLog(@"Betting amount = %ld", sliderValue);
    _betAmountLabel.text = [NSString stringWithFormat:@"%ld",sliderValue];
}

-(void)showAlertWithTitle:(NSString*)title andMessage:(NSString*)message
{
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                          handler:^(UIAlertAction * action) {}];
    
    [alert addAction:defaultAction];
    [self presentViewController:alert animated:YES completion:nil];

    
}


- (IBAction)instructionsBtnTapped:(id)sender {
    
}

- (IBAction)authorBtnTapped:(id)sender {
    
}
- (IBAction)resetBtnTapped:(id)sender {
    
    _amountLabel.text = @"0";
    _roundLabel.text = @"0";
    
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"amountInAccount"];
    
}

@end
