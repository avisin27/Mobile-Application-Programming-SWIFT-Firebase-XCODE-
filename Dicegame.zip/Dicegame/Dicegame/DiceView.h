

#import <UIKit/UIKit.h>

@interface DiceView : UIView

@property NSInteger dieValue;

- (id)initWithFrame:(CGRect)frame andValue:(NSInteger)value;

- (void)spinThisDieFor:(float)duration;

@end
