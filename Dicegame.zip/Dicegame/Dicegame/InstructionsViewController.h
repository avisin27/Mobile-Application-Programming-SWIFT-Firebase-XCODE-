//
//  InstructionsViewController.h
//  Dice Roll Game
//
//  Created by Avi Singhal on 20/02/2018.
// Copyright © 2018 Apple Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InstructionsViewController : UIViewController

@end
