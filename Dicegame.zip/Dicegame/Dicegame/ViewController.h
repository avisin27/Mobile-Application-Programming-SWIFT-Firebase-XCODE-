//
//  ViewController.h
//  Dice Roll Game
//
///  Created by Avi Singhal on 20/02/2018.
// Copyright © 2018 Apple Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DiceView.h"

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet DiceView *dice1View;
@property (strong, nonatomic) IBOutlet DiceView *dice2view;
- (IBAction)instructionsBtnTapped:(id)sender;
- (IBAction)authorBtnTapped:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *amountLabel;
@property (weak, nonatomic) IBOutlet UISlider *betSlider;
@property (weak, nonatomic) IBOutlet UILabel *roundLabel;
@property (weak, nonatomic) IBOutlet UILabel *betAmountLabel;


@end

