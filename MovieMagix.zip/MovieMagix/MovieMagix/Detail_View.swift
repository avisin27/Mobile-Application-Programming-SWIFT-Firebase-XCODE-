//
//  Detail_View.swift
//  Music Magic
//
//  Created by Avi Singhal on 03/19/18.
//  Copyright © 2018 Apple Inc. All rights reserved.
//

import UIKit

class Detail_View: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {

    var  str_title:String = String()
    var  str_release_dt:String = String()
    var  str_overview:String = String()
    var  arr_img:[String] = [String]()
    var  genre_id:[Int] = [Int]()
    var  arr_genre:[ViewController.genres] = [ViewController.genres]()
    var  str_genre:String = String()
    var  rating:Int = Int()
    
    var Colle_View: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    
        let lbl_title:UILabel = UILabel(frame:CGRect(x: 5, y: (self.navigationController?.navigationBar.frame.size.height)!+50, width: self.view.frame.size.width-10, height: 30))
        lbl_title.text = str_title
        self.view.addSubview(lbl_title)
        
        let view_rate:UIView = UIView(frame:CGRect(x: 5, y: lbl_title.frame.maxY, width: self.view.frame.size.width-10, height: 30))
        self.view.addSubview(view_rate)
        
        for inx in 0...9{
            
            let imgview:UIImageView = UIImageView(frame:CGRect(x: inx*30, y: 0, width: 30, height: 30))
            
            if rating > inx{
                 imgview.image = UIImage(named:"star_fill")
            }
            else{
                imgview.image = UIImage(named:"star")
            }
           
            view_rate.addSubview(imgview)
        }
        let lbl_release:UILabel = UILabel(frame:CGRect(x: 5, y: view_rate.frame.maxY, width: 65, height: 30))
        lbl_release.text = "Release:"
        self.view.addSubview(lbl_release)
        
        let lbl_release_title:UILabel = UILabel(frame:CGRect(x: lbl_release.frame.maxX, y: view_rate.frame.maxY, width: 300, height: 30))
        lbl_release_title.text = str_release_dt
        self.view.addSubview(lbl_release_title)
        
        let lbl_genre:UILabel = UILabel(frame:CGRect(x: 5, y: lbl_release.frame.maxY, width: 55, height: 30))
        lbl_genre.text = "Genre:"
        self.view.addSubview(lbl_genre)
        
        print(genre_id)
        print(arr_genre)
        
        
        for id in genre_id{
            for data in arr_genre{
                if data.id == id{
                    if str_genre == ""{
                        str_genre = "\(data.name)"
                    }
                    else{
                        str_genre = "\(str_genre),\(data.name)"
                    }
                }
            }
        }
        let lbl_genre_title:UILabel = UILabel(frame:CGRect(x: lbl_release.frame.maxX, y:lbl_release.frame.maxY, width: self.view.frame.size.width-60, height: 30))
        lbl_genre_title.text = str_genre
        lbl_genre_title.font = lbl_genre_title.font.withSize(13)
        lbl_genre_title.textColor = UIColor.gray
        self.view.addSubview(lbl_genre_title)
        
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right:0)
        layout.itemSize = CGSize(width: self.view.frame.size.height/3, height: self.view.frame.size.height/3)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 5
        layout.scrollDirection = .horizontal
        
        Colle_View = UICollectionView(frame: CGRect(x: 5, y: lbl_genre_title.frame.maxY, width: self.view.frame.size.width-10, height: self.view.frame.size.height/3), collectionViewLayout: layout)
        
        Colle_View.frame = CGRect(x: 5, y: lbl_genre_title.frame.maxY, width: self.view.frame.size.width-10, height: self.view.frame.size.height/3)
        Colle_View.register(cell_img.self, forCellWithReuseIdentifier: "cell")
        Colle_View.delegate = self
        Colle_View.dataSource = self
        Colle_View.backgroundColor = UIColor.white
        self.view.addSubview(Colle_View)
    
        let lbl_overview:UILabel = UILabel(frame:CGRect(x: 5, y:Colle_View.frame.maxY, width: self.view.frame.size.width-10, height: 100))
        lbl_overview.text = str_overview
        lbl_overview.font = lbl_overview.font.withSize(13)
        lbl_overview.numberOfLines = 50
        self.view.addSubview(lbl_overview)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = Colle_View.dequeueReusableCell(
            withReuseIdentifier: "cell", for: indexPath) as! cell_img
        
        cell.img_view.image = UIImage(named: "logo")
        
        let str_img:String = "\(URL_main_image_small)\(arr_img[indexPath.row])"
        
        let escapedString = str_img.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlQueryAllowed)
        downloadImage_search(indexPath: indexPath,cell: cell, url: URL(string: escapedString!)!) { (img) in
            cell.img_view.image = img
        }
        return cell
    }
    
    func downloadImage_search(indexPath: IndexPath,cell:cell_img,url:URL, callback: @escaping (UIImage?) -> ()) {
        let task = URLSession.shared.dataTask(with: url) { (responseData, responseUrl, error) -> Void in
            // if responseData is not null...
            //cell.AI.startAnimating()
            if let data = responseData {
                // execute in UI thread
                DispatchQueue.main.sync {
                    //cell.AI.startAnimating()
                    callback(UIImage(data: data))
                }
            }
            else {
                DispatchQueue.main.sync {
                    //cell.AI.stopAnimating()
                    callback(nil)
                }
            }
        }
        
        // Run task
        task.resume()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
