//
//  Alert_View.swift
//  KDXPeople
//
//  Created by Avi Singhal on 03/19/18.
//  Copyright © 2018 Apple Inc. All rights reserved.
//

import UIKit

class Alert_View: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    func error_Alert(_ title: String,message:String,vc:UIViewController){
        let alert = UIAlertController.init(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
        }))
        vc.present(alert, animated: true, completion: nil)
    }

}
