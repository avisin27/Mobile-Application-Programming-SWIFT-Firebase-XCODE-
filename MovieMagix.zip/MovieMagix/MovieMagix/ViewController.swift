//
//  ViewController.swift
//  Music Magic
//
//  Created by Avi Singhal on 03/20/18.
//  Copyright © 2018 Apple Inc. All rights reserved.//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{

    var tblview:UITableView = UITableView()
    
    var  str_title:String = String()
    var  str_release_dt:String = String()
    var  str_overview:String = String()
    var  arr_img:[String] = [String]()
    var  genre_id:[Int] = [Int]()
    var  rating:Float = Float()

    var  slc_id:Int = Int()
    
    var arr_now_playing:[results] = [results]()
    var arr_popular:[results] = [results]()
    var arr_top_rated:[results] = [results]()
    var arr_upcoming:[results] = [results]()
   
    var arr_genre:[genres] = [genres]()
    
    struct results: Codable {
        let title: String
        let release_date: String
        let overview: String
        let poster_path: String
        let backdrop_path: String
        let genre_ids: [Int]
        let vote_average: Float
    }
    
    struct Movie_list: Codable {
        let results: [results]
    }
    
    
    struct genres: Codable {
        let name: String
        let id: Int
    }
    
    struct genreslist: Codable {
        let genres: [genres]
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    
        tblview = UITableView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height:self.view.frame.size.height))
        tblview.register(UITableViewCell.self, forCellReuseIdentifier: "MyCell")
        tblview.dataSource = self
        tblview.delegate = self
        self.view.addSubview(tblview)
        
    }

    override func viewWillAppear(_ animated: Bool) {
        webservice_now_paying()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let view:UIView = UIView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 30))
        view.backgroundColor = UIColor.black
        let lbl:UILabel = UILabel(frame: CGRect(x: 5, y: 0, width: self.view.frame.size.width-10, height: 30))

        lbl.textColor = UIColor.white
        if section == 0{
            lbl.text = "Now Playing"
        }
        else if section == 1{
            lbl.text = "Popular"

        }
        else if section == 2{
            lbl.text = "Top Rated"

        }
        else {
            lbl.text = "Upcoming"
        }
        view.addSubview(lbl)
        
        return view
        
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0{
            return arr_now_playing.count
        }
        else if section == 1{
            return arr_popular.count
        }
        else if section == 2{
            return arr_top_rated.count
        }
        else {
            return arr_upcoming.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath as IndexPath)

        var str_img:String = String()
        var str_title:String = String()

        cell.imageView?.image = UIImage(named: "logo")
        if indexPath.section == 0{
            let data = arr_now_playing[indexPath.row]
            str_title = data.title
            str_img = data.poster_path
        }
        else if indexPath.section == 1{
            let data = arr_popular[indexPath.row]
            str_title = data.title
            str_img = data.poster_path
        }
        else if indexPath.section == 2{
            let data = arr_top_rated[indexPath.row]
            str_title = data.title
            str_img = data.poster_path
        }
        else {
            let data = arr_upcoming[indexPath.row]
            str_title = data.title
            str_img = data.poster_path
        }
        
        str_img = "\(URL_main_image_small)\(str_img)"
        cell.textLabel!.text = str_title
        let escapedString = str_img.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlQueryAllowed)
        downloadImage_search(indexPath: indexPath,cell: cell, url: URL(string: escapedString!)!) { (img) in
            cell.imageView?.image = img
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        if indexPath.section == 0{
            let data = arr_now_playing[indexPath.row]
            str_title = data.title
            str_release_dt = data.release_date
            str_overview = data.overview
            arr_img = ["\(data.poster_path)","\(data.backdrop_path)"]
            genre_id = data.genre_ids
            rating = data.vote_average
        }
        else if indexPath.section == 1{
            let data = arr_popular[indexPath.row]
            str_title = data.title
            str_release_dt = data.release_date
            str_overview = data.overview
            arr_img = ["\(data.poster_path)","\(data.backdrop_path)"]
            genre_id = data.genre_ids
            rating = data.vote_average

        }
        else if indexPath.section == 2{
            let data = arr_top_rated[indexPath.row]
            str_title = data.title
            str_release_dt = data.release_date
            str_overview = data.overview
            arr_img = ["\(data.poster_path)","\(data.backdrop_path)"]
            genre_id = data.genre_ids
            rating = data.vote_average

        }
        else {
            let data = arr_upcoming[indexPath.row]
            str_title = data.title
            str_release_dt = data.release_date
            str_overview = data.overview
            arr_img = ["\(data.poster_path)","\(data.backdrop_path)"]
            genre_id = data.genre_ids
            rating = data.vote_average

        }
        
        self.performSegue(withIdentifier: "id", sender: self)
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            if indexPath.section == 0{
                arr_now_playing.remove(at: indexPath.row)
            }
            else if indexPath.section == 1{
                arr_popular.remove(at: indexPath.row)
            }
            else if indexPath.section == 2{
                arr_top_rated.remove(at: indexPath.row)
            }
            else{
                arr_upcoming.remove(at: indexPath.row)
            }
            
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
        
    }

    func downloadImage_search(indexPath: IndexPath,cell:UITableViewCell,url:URL, callback: @escaping (UIImage?) -> ()) {
        let task = URLSession.shared.dataTask(with: url) { (responseData, responseUrl, error) -> Void in
            // if responseData is not null...
            //cell.AI.startAnimating()
            if let data = responseData {
                // execute in UI thread
                DispatchQueue.main.sync {
                    //cell.AI.startAnimating()
                    callback(UIImage(data: data))
                }
            }
            else {
                DispatchQueue.main.sync {
                    //cell.AI.stopAnimating()
                    callback(nil)
                }
            }
        }
        
        // Run task
        task.resume()
    }


    func webservice_now_paying() {
        
        Webservice().call_webservice_GET(view_load: self.view, str_URL: URL_cmn().URL_now_playing) { (data,error) in
            
            if error != nil{
                Alert_View().error_Alert("Error", message: "Enable to Get data",vc: self)
                //print(error?.localizedDescription)
                
            }
            else{
                do {
                    let decoder = JSONDecoder()
                    let gitData = try decoder.decode(Movie_list.self, from: data!)
                    self.arr_now_playing = gitData.results
                    self.webservice_popular()
                } catch let err {
                    print("Err", err)
                }
            }
        }
    }
    
    func webservice_popular() {
        
        Webservice().call_webservice_GET(view_load: self.view, str_URL: URL_cmn().URL_popular) { (data,error) in
            
            if error != nil{
                Alert_View().error_Alert("Error", message: "Enable to Get data",vc: self)
                //print(error?.localizedDescription)
                
            }
            else{
                do {
                    let decoder = JSONDecoder()
                    let gitData = try decoder.decode(Movie_list.self, from: data!)
                    self.arr_popular = gitData.results
                    self.webservice_top_rated()

                } catch let err {
                    print("Err", err)
                }
                
            }
        }
    }
    
    func webservice_top_rated() {
        
        Webservice().call_webservice_GET(view_load: self.view, str_URL: URL_cmn().URL_top_rated) { (data,error) in
            
            if error != nil{
                Alert_View().error_Alert("Error", message: "Enable to Get data",vc: self)
                //print(error?.localizedDescription)
                
            }
            else{
                do {
                    let decoder = JSONDecoder()
                    let gitData = try decoder.decode(Movie_list.self, from: data!)
                    self.arr_top_rated = gitData.results
                    self.webservice_upcoming()

                } catch let err {
                    print("Err", err)
                }
                
            }
        }
    }
    
    func webservice_upcoming() {
        
        Webservice().call_webservice_GET(view_load: self.view, str_URL: URL_cmn().URL_upcomming) { (data,error) in
            
            if error != nil{
                Alert_View().error_Alert("Error", message: "Enable to Get data",vc: self)
                //print(error?.localizedDescription)
            }
            else{
                do {
                    let decoder = JSONDecoder()
                    let gitData = try decoder.decode(Movie_list.self, from: data!)
                    self.arr_upcoming = gitData.results
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.tblview.reloadData()
                        self.webservice_genre()
                    })
                } catch let err {
                    print("Err", err)
                }
                
            }
        }
    }
    
    func webservice_genre() {
        
        Webservice().call_webservice_GET(view_load: self.view, str_URL: URL_cmn().URL_genre_list) { (data,error) in
            
            if error != nil{
                Alert_View().error_Alert("Error", message: "Enable to Get data",vc: self)
                //print(error?.localizedDescription)
            }
            else{
                do {
                    let decoder = JSONDecoder()
                    let gitData = try decoder.decode(genreslist.self, from: data!)
                    self.arr_genre = gitData.genres
                    
                } catch let err {
                    print("Err", err)
                }
            }
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier=="id" {
            let vc:Detail_View = segue.destination as! Detail_View
            vc.str_title = str_title
            vc.rating = Int(rating)
            vc.str_release_dt = str_release_dt
            vc.str_overview = str_overview
            vc.arr_img = arr_img
            vc.arr_genre = arr_genre
            vc.genre_id = genre_id
        }
    }

}

