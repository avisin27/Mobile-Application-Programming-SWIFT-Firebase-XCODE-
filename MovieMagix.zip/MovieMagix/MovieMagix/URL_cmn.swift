//
//  URL_cmn.swift
//  KDXPeople
//
//  Created by Avi Singhal on 03/20/18.
//  Copyright © 2018 Apple Inc. All rights reserved.
//

import UIKit

let URL_main_moview: String = "http://api.themoviedb.org/3/movie/"
let URL_main_genre: String = "https://api.themoviedb.org/3/genre/movie/"
let URL_main_image_small: String = "http://image.tmdb.org/t/p/w185/"
let URL_main_image_large: String = "http://image.tmdb.org/t/p/w500/"

let str_key: String = "9fdd6531a996b28ce42f6e2a29636321"
class URL_cmn: NSObject {
    
    let URL_popular:String="\(URL_main_moview)popular?api_key=\(str_key)"
    let URL_now_playing:String="\(URL_main_moview)now_playing?api_key=\(str_key)"
    let URL_top_rated:String="\(URL_main_moview)top_rated?api_key=\(str_key)"
    let URL_upcomming:String="\(URL_main_moview)upcoming?api_key=\(str_key)"
    
    let URL_genre_list:String="\(URL_main_genre)list?api_key=\(str_key)"
}
