//
//  Webservice.swift
//  KDXPeople
//
//  Created by Avi Singhal on 03/20/18.
//  Copyright © 2018 Apple Inc. All rights reserved.
//

import UIKit

class Webservice: NSObject {
    
    func call_webservice_GET(view_load:UIView,str_URL:String,handler:@escaping (Data?,Error?)-> ()) {
        
        print(str_URL)
        
        let view_loading:UIView=UIView(frame:CGRect(x: 0, y: 0, width: view_load.frame.size.width, height: view_load.frame.size.height))
        //view_loading.backgroundColor = UIColor.init(colorLiteralRed: 9/256, green: 73/256, blue: 65/256, alpha: 0.7)
        view_loading.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        view_load.addSubview(view_loading)
        
        let blurEffect = UIBlurEffect(style: UIBlurEffectStyle.dark)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        //always fill the view
        blurEffectView.frame = view_loading.bounds
        blurEffectView.alpha=0.4
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        
        view_loading.addSubview(blurEffectView)
        
        let img_ldr:UIImageView=UIImageView(frame:CGRect(x: view_loading.center.x-25, y: view_loading.center.y-25, width: 50, height: 50))
        img_ldr.image = UIImage(named: "ldr")
        view_loading.addSubview(img_ldr)
        
        let kRotationAnimationKey = "com.myapplication.rotationanimationkey"
        let rotationAnimation = CABasicAnimation(keyPath: "transform.rotation")
        
        rotationAnimation.fromValue = 0.0
        rotationAnimation.toValue = Float(Double.pi * 2.0)
        rotationAnimation.duration = 0.5
        rotationAnimation.repeatCount = Float.infinity
        
        img_ldr.layer.add(rotationAnimation, forKey: kRotationAnimationKey)
        
        let session = URLSession.shared
        
        var request = URLRequest(url: URL(string: str_URL.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!)
        
        request.httpMethod = "GET"
    
        request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
        
        let task = session.dataTask(with: request, completionHandler: {
            (
            data, response, error) in
            
            DispatchQueue.main.sync {
                view_loading.isHidden=true
                view_loading.removeFromSuperview()
            }
            
            handler(data,error)
            
        })
        
        task.resume()
        
    }
    
    
}

