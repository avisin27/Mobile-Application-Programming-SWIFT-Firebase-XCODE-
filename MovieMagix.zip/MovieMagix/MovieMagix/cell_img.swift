//
//  cell_img.swift
//  Music Magic
//
//  Created by Avi Singhal on 03/19/18.
//  Copyright © 2018 Apple Inc. All rights reserved.
//

import UIKit

class cell_img: UICollectionViewCell {
    
    var img_view:UIImageView = UIImageView()
    override init(frame: CGRect) {
        super.init(frame: frame)
   
        img_view.frame = CGRect(x: 0, y: 0, width: frame.size.width, height: frame.size.height)
        self.addSubview(img_view)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
